#include "item.h"
void Item::onCollide(CollidableObject *object) {

}
