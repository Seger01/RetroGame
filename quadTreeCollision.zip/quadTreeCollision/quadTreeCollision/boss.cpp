#include "boss.h"
void Boss::onCollide(CollidableObject *object){


}
